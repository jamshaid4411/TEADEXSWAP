const hre = require("hardhat");

async function main() {
    const TeaDEX = await hre.ethers.getContractFactory("TeaDEX");
    const teaDEX = await TeaDEX.deploy();
    await teaDEX.deployed();
    console.log(`TeaDEX deployed at: ${teaDEX.address}`);
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
